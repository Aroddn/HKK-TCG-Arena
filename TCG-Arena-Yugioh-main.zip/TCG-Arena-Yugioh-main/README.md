Data for playing Yugioh on TCG-Arena.fr

To test updates on the game data, make changes to Game_Yu-Gi-Oh-Testing.json.
Changes pushed to the repo will be live on the app after a few minutes.

To add the Yu-Gi-Oh test game to TCG Arena click this link

https://tcg-arena.fr/load/aHR0cHMlM0ElMkYlMkZ2YWxjdXIuZ2l0aHViLmlvJTJGVENHLUFyZW5hLVl1Z2lvaCUyRkdhbWVfWXUtR2ktT2gtVGVzdGluZy5qc29u

Make sure it works there before copying the changes and applying them to the real game file.

